package com.example.autoreplytosms;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import android.content.Context;
import android.widget.Toast;

public class File {

	Context con;
	
	String filename = "data";
	
	public File(Context con) {
	this.con = con;
	
	}
	
	public MsgBean read()
	{
		MsgBean obj = null;
		try {
			FileInputStream fis = con.openFileInput(filename);
			ObjectInputStream ois = new ObjectInputStream(fis);
			obj = (MsgBean) ois.readObject();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Toast.makeText(con, "Error in read", 0).show();
			obj = new MsgBean("");
		}
		return obj;
	}
	
	public void write(MsgBean msg)
	{
		try {
			FileOutputStream fos = con.openFileOutput(filename, Context.MODE_PRIVATE);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(msg);
			oos.flush();
			oos.close();
			fos.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Toast.makeText(con, "Error in write", 0).show();
			
		}
		
	}
}

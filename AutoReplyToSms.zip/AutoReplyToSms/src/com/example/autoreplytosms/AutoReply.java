package com.example.autoreplytosms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;

public class AutoReply extends BroadcastReceiver{
	boolean value=true;
	File file = null;
	@Override
	public void onReceive(Context arg0, Intent arg1) {
		// TODO Auto-generated method stub
		file = new File(arg0);
		if(Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(arg1.getAction()))
		{
			
			for(SmsMessage sms : Telephony.Sms.Intents.getMessagesFromIntent(arg1))
			{
				String msg = sms.getDisplayMessageBody();
				String add = sms.getOriginatingAddress();
				
				MsgBean obj  = file.read();
				String mymsg = obj.getSavedmsg();
				if(value)
				{			
				SmsManager smssend = SmsManager.getDefault();
				smssend.sendTextMessage(add, null, mymsg, null, null);
				
			}
				else
				{
					
			}
		}
			}
	}
}

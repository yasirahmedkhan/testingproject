package com.example.autoreplytosms;

import java.io.Serializable;

public class MsgBean implements Serializable {

	String savedmsg;
	
	public MsgBean(String savedmsg) {
		this.savedmsg = savedmsg;
	}

	public String getSavedmsg() {
		return savedmsg;
	}

	public void setSavedmsg(String savedmsg) {
		this.savedmsg = savedmsg;
	}

	@Override
	public String toString() {
		return "MsgBean [savedmsg=" + savedmsg + "]";
	}
	
	
}
